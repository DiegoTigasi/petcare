package com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas;

import java.util.List;

import com.DiegoTigasi.petCareApi.dominio.entidades.ConsultaServicio;

public interface IConsultaServicioUseCase {

	ConsultaServicio guardar(ConsultaServicio nuevoConsultaServicio);

	ConsultaServicio buscarPorId(int idConsultaServicio);

	List<ConsultaServicio> listarTodos();

	void eliminar(int idConsultaServicio);

	List<ConsultaServicio> listarPorConsulta(int idConsulta);
}
