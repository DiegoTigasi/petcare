package com.DiegoTigasi.petCareApi.infraestructura.persistencia.adaptadores;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IConsultaRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.ConsultaEntity;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores.IConsultaJpaMapper;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IConsultaJpaRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IMascotaJpaRepositorio;

public class ConsultaRepositorioImpl implements IConsultaRepositorio {

	private final IConsultaJpaRepositorio jpaRepositorio;
	private final IMascotaJpaRepositorio mascotaJpaRepositorio;
	private final IConsultaJpaMapper entityMapper;

	public ConsultaRepositorioImpl(IConsultaJpaRepositorio jpaRepositorio, IMascotaJpaRepositorio mascotaJpaRepositorio,
			IConsultaJpaMapper entityMapper) {
		this.jpaRepositorio = jpaRepositorio;
		this.mascotaJpaRepositorio = mascotaJpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Consulta guardar(Consulta nuevaConsulta) {
		ConsultaEntity entity = entityMapper.toEntity(nuevaConsulta);
		entity.setFkMascotaEntity(mascotaJpaRepositorio.getReferenceById(nuevaConsulta.getFkMascota().getIdMascota()));
		ConsultaEntity guardado = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardado);
	}

	@Override
	public Optional<Consulta> buscarPorId(int idConsulta) {
		return jpaRepositorio.findById(idConsulta).map(entityMapper::toDomain);
	}

	@Override
	public List<Consulta> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int idConsulta) {
		jpaRepositorio.deleteById(idConsulta);
	}

	@Override
	public List<Consulta> listarAtencionesValidasEntreFechas(Date desde, Date hasta) {
		return jpaRepositorio.listarAtencionesValidasEntreFechas(desde, hasta).stream().map(entityMapper::toDomain)
				.toList();
	}
}
