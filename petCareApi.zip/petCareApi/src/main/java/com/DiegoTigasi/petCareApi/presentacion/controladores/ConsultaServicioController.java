package com.DiegoTigasi.petCareApi.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IConsultaServicioUseCase;
import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;
import com.DiegoTigasi.petCareApi.dominio.entidades.ConsultaServicio;
import com.DiegoTigasi.petCareApi.presentacion.dto.request.ConsultaServicioRequestDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.ConsultaServicioResponseDto;
import com.DiegoTigasi.petCareApi.presentacion.mapeadores.IConsultaServicioDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/petcare/consulta-servicio")
public class ConsultaServicioController {

	private final IConsultaServicioUseCase consultaServicioUseCase;
	private final IConsultaServicioDtoMapper mapper;

	public ConsultaServicioController(IConsultaServicioUseCase consultaServicioUseCase, IConsultaServicioDtoMapper mapper) {
		this.consultaServicioUseCase = consultaServicioUseCase;
		this.mapper = mapper;
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public ConsultaServicioResponseDto guardar(@Valid @RequestBody ConsultaServicioRequestDto requestConsultaServicio) {
		return mapper.toResponseDto(consultaServicioUseCase.guardar(aDominioConFkConsulta(requestConsultaServicio)));
	}

	@GetMapping
	public List<ConsultaServicioResponseDto> listarTodos() {
		return consultaServicioUseCase.listarTodos().stream().map(mapper::toResponseDto).toList();
	}

	@GetMapping("/{idConsultaServicio}")
	public ConsultaServicioResponseDto buscarPorId(@PathVariable int idConsultaServicio) {
		return mapper.toResponseDto(consultaServicioUseCase.buscarPorId(idConsultaServicio));
	}

	@PutMapping("/{idConsultaServicio}")
	public ConsultaServicioResponseDto editar(@PathVariable int idConsultaServicio,
			@Valid @RequestBody ConsultaServicioRequestDto requestConsultaServicio) {
		requestConsultaServicio.setIdConsultaServicio(idConsultaServicio);
		return mapper.toResponseDto(consultaServicioUseCase.guardar(aDominioConFkConsulta(requestConsultaServicio)));
	}

	@DeleteMapping("/{idConsultaServicio}")
	public ResponseEntity<Void> eliminar(@PathVariable int idConsultaServicio) {
		consultaServicioUseCase.eliminar(idConsultaServicio);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/consulta/{idConsulta}")
	public List<ConsultaServicioResponseDto> listarPorConsulta(@PathVariable int idConsulta) {
		return consultaServicioUseCase.listarPorConsulta(idConsulta).stream().map(mapper::toResponseDto).toList();
	}

	private ConsultaServicio aDominioConFkConsulta(ConsultaServicioRequestDto requestConsultaServicio) {
		ConsultaServicio consultaServicio = mapper.toDomain(requestConsultaServicio);
		Consulta consultaRef = new Consulta();
		consultaRef.setIdConsulta(requestConsultaServicio.getIdConsulta());
		consultaServicio.setFkConsulta(consultaRef);
		return consultaServicio;
	}
}
