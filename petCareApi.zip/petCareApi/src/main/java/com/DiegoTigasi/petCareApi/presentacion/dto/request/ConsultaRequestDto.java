package com.DiegoTigasi.petCareApi.presentacion.dto.request;

import java.util.Date;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ConsultaRequestDto {

	private int idConsulta;
	@Min(1)
	private int idMascota;
	@NotBlank
	private String veterinarioNombre;
	@NotNull
	private Date fecha;
	@NotBlank
	private String motivo;
	private String diagnostico;
	@NotBlank
	private String estado;
}
