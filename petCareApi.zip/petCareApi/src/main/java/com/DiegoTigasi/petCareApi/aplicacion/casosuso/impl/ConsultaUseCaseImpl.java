package com.DiegoTigasi.petCareApi.aplicacion.casosuso.impl;

import java.util.Date;
import java.util.List;

import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IConsultaUseCase;
import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IConsultaRepositorio;

public class ConsultaUseCaseImpl implements IConsultaUseCase {

	private final IConsultaRepositorio repositorio;

	public ConsultaUseCaseImpl(IConsultaRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Consulta guardar(Consulta nuevaConsulta) {
		return repositorio.guardar(nuevaConsulta);
	}

	@Override
	public Consulta buscarPorId(int idConsulta) {
		return repositorio.buscarPorId(idConsulta)
				.orElseThrow(() -> new RuntimeException("Consulta no encontrada"));
	}

	@Override
	public List<Consulta> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int idConsulta) {
		repositorio.eliminar(idConsulta);
	}

	@Override
	public List<Consulta> listarAtencionesValidasEntreFechas(Date desde, Date hasta) {
		return repositorio.listarAtencionesValidasEntreFechas(desde, hasta);
	}
}
