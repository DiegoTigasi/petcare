package com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.DiegoTigasi.petCareApi.dominio.entidades.ConsultaServicio;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.ConsultaServicioEntity;

@Mapper(componentModel = "spring", uses = IConsultaJpaMapper.class)
public interface IConsultaServicioJpaMapper {

	@Mapping(source = "fkConsultaEntity", target = "fkConsulta")
	ConsultaServicio toDomain(ConsultaServicioEntity entity);

	ConsultaServicioEntity toEntity(ConsultaServicio consultaServicioPojo);
}
