package com.DiegoTigasi.petCareApi.infraestructura.configuraciones;

import java.sql.Date;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IMascotaRepositorio;

@Component
public class MascotaSeeder implements CommandLineRunner {

	private final IMascotaRepositorio mascotaRepositorio;

	public MascotaSeeder(IMascotaRepositorio mascotaRepositorio) {
		this.mascotaRepositorio = mascotaRepositorio;
	}

	@Override
	public void run(String... args) {
		if (!mascotaRepositorio.listarTodos().isEmpty()) {
			return;
		}

		mascotaRepositorio.guardar(nuevaMascota("Firulais", "Perro", "Labrador", "Macho",
				Date.valueOf("2022-03-15"), "Juan Pérez", "1712345678", "0991234567"));
		mascotaRepositorio.guardar(nuevaMascota("Michi", "Gato", "Siames", "Hembra",
				Date.valueOf("2021-07-02"), "María López", "1798765432", "0987654321"));
		mascotaRepositorio.guardar(nuevaMascota("Rocky", "Perro", "Pastor Alemán", "Macho",
				Date.valueOf("2020-11-20"), "Carlos Andrade", "1723456789", "0976543210"));
	}

	private Mascota nuevaMascota(String nombre, String especie, String raza, String sexo,
			Date fechaNacimiento, String propietarioNombre, String propietarioCedula, String propietarioTelefono) {
		Mascota mascota = new Mascota();
		mascota.setNombre(nombre);
		mascota.setEspecie(especie);
		mascota.setRaza(raza);
		mascota.setSexo(sexo);
		mascota.setFechaNacimiento(fechaNacimiento);
		mascota.setPropietarioNombre(propietarioNombre);
		mascota.setPropietarioCedula(propietarioCedula);
		mascota.setPropietarioTelefono(propietarioTelefono);
		mascota.setEstadoRegistro(true);
		return mascota;
	}
}
