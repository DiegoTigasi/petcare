package com.DiegoTigasi.petCareApi.infraestructura.configuraciones;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IConsultaServicioUseCase;
import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IConsultaUseCase;
import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IMascotaUseCase;
import com.DiegoTigasi.petCareApi.aplicacion.casosuso.impl.ConsultaServicioUseCaseImpl;
import com.DiegoTigasi.petCareApi.aplicacion.casosuso.impl.ConsultaUseCaseImpl;
import com.DiegoTigasi.petCareApi.aplicacion.casosuso.impl.MascotaUseCaseImpl;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IConsultaRepositorio;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IConsultaServicioRepositorio;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IMascotaRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.adaptadores.ConsultaRepositorioImpl;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.adaptadores.ConsultaServicioRepositorioImpl;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.adaptadores.MascotaRepositorioImpl;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores.IConsultaJpaMapper;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores.IConsultaServicioJpaMapper;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores.IMascotaJpaMapper;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IConsultaJpaRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IConsultaServicioJpaRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IMascotaJpaRepositorio;

@Configuration
public class PetCareConfig {

	/* Mascota */
	@Bean
	IMascotaRepositorio mascotaRepositorio(IMascotaJpaRepositorio jpaRepositorio, IMascotaJpaMapper mapper) {
		return new MascotaRepositorioImpl(jpaRepositorio, mapper);
	}

	@Bean
	IMascotaUseCase mascotaUseCase(IMascotaRepositorio repo) {
		return new MascotaUseCaseImpl(repo);
	}

	/* Consulta */
	@Bean
	IConsultaRepositorio consultaRepositorio(IConsultaJpaRepositorio jpaRepositorio,
			IMascotaJpaRepositorio mascotaJpaRepositorio, IConsultaJpaMapper mapper) {
		return new ConsultaRepositorioImpl(jpaRepositorio, mascotaJpaRepositorio, mapper);
	}

	@Bean
	IConsultaUseCase consultaUseCase(IConsultaRepositorio repo) {
		return new ConsultaUseCaseImpl(repo);
	}

	/* ConsultaServicio */
	@Bean
	IConsultaServicioRepositorio consultaServicioRepositorio(IConsultaServicioJpaRepositorio jpaRepositorio,
			IConsultaJpaRepositorio consultaJpaRepositorio, IConsultaServicioJpaMapper mapper) {
		return new ConsultaServicioRepositorioImpl(jpaRepositorio, consultaJpaRepositorio, mapper);
	}

	@Bean
	IConsultaServicioUseCase consultaServicioUseCase(IConsultaServicioRepositorio repo) {
		return new ConsultaServicioUseCaseImpl(repo);
	}
}
