package com.DiegoTigasi.petCareApi.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.DiegoTigasi.petCareApi.dominio.entidades.ConsultaServicio;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IConsultaServicioRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.ConsultaServicioEntity;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores.IConsultaServicioJpaMapper;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IConsultaJpaRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IConsultaServicioJpaRepositorio;

public class ConsultaServicioRepositorioImpl implements IConsultaServicioRepositorio {

	private final IConsultaServicioJpaRepositorio jpaRepositorio;
	private final IConsultaJpaRepositorio consultaJpaRepositorio;
	private final IConsultaServicioJpaMapper entityMapper;

	public ConsultaServicioRepositorioImpl(IConsultaServicioJpaRepositorio jpaRepositorio,
			IConsultaJpaRepositorio consultaJpaRepositorio, IConsultaServicioJpaMapper entityMapper) {
		this.jpaRepositorio = jpaRepositorio;
		this.consultaJpaRepositorio = consultaJpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public ConsultaServicio guardar(ConsultaServicio nuevoConsultaServicio) {
		ConsultaServicioEntity entity = entityMapper.toEntity(nuevoConsultaServicio);
		entity.setFkConsultaEntity(
				consultaJpaRepositorio.getReferenceById(nuevoConsultaServicio.getFkConsulta().getIdConsulta()));
		ConsultaServicioEntity guardado = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardado);
	}

	@Override
	public Optional<ConsultaServicio> buscarPorId(int idConsultaServicio) {
		return jpaRepositorio.findById(idConsultaServicio).map(entityMapper::toDomain);
	}

	@Override
	public List<ConsultaServicio> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int idConsultaServicio) {
		jpaRepositorio.deleteById(idConsultaServicio);
	}

	@Override
	public List<ConsultaServicio> listarPorConsulta(int idConsulta) {
		return jpaRepositorio.listarPorConsulta(idConsulta).stream().map(entityMapper::toDomain).toList();
	}
}
