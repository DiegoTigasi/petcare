package com.DiegoTigasi.petCareApi.presentacion.mapeadores;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;
import com.DiegoTigasi.petCareApi.presentacion.dto.request.ConsultaRequestDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.ConsultaReporteResponseDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.ConsultaResponseDto;

@Mapper(componentModel = "spring")
public interface IConsultaDtoMapper {

	@Mapping(target = "fkMascota", ignore = true)
	Consulta toDomain(ConsultaRequestDto dto);

	ConsultaResponseDto toResponseDto(Consulta consultaPojo);

	@Mapping(source = "fkMascota.propietarioNombre", target = "propietarioNombre")
	@Mapping(source = "fkMascota.nombre", target = "mascotaNombre")
	@Mapping(source = "fkMascota.especie", target = "especie")
	ConsultaReporteResponseDto toReporteDto(Consulta consultaPojo);
}
