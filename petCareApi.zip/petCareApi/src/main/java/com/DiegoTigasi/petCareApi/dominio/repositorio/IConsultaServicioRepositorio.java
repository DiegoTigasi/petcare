package com.DiegoTigasi.petCareApi.dominio.repositorio;

import java.util.List;
import java.util.Optional;

import com.DiegoTigasi.petCareApi.dominio.entidades.ConsultaServicio;

public interface IConsultaServicioRepositorio {

	ConsultaServicio guardar(ConsultaServicio nuevoConsultaServicio);

	Optional<ConsultaServicio> buscarPorId(int idConsultaServicio);

	List<ConsultaServicio> listarTodos();

	void eliminar(int idConsultaServicio);

	List<ConsultaServicio> listarPorConsulta(int idConsulta);
}
