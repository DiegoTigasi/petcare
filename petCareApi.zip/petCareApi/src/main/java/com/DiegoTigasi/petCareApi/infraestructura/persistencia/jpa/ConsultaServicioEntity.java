package com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "consulta_servicio")
public class ConsultaServicioEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idConsultaServicio;
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_consulta")
	private ConsultaEntity fkConsultaEntity;
	private String servicioNombre;
	private double precio;
	private int cantidad;
}
