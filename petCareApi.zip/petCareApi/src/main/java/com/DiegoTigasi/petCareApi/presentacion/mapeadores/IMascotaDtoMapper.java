package com.DiegoTigasi.petCareApi.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;
import com.DiegoTigasi.petCareApi.presentacion.dto.request.MascotaRequestDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.MascotaResponseDto;

@Mapper(componentModel = "spring")
public interface IMascotaDtoMapper {

	Mascota toDomain(MascotaRequestDto dto);

	MascotaResponseDto toResponseDto(Mascota mascotaPojo);
}
