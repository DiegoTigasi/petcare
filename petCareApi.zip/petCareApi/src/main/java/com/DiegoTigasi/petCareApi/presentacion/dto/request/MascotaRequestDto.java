package com.DiegoTigasi.petCareApi.presentacion.dto.request;

import java.util.Date;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MascotaRequestDto {

	private int idMascota;
	@NotBlank
	private String nombre;
	@NotBlank
	private String especie;
	private String raza;
	private String sexo;
	@NotNull
	private Date fechaNacimiento;
	@NotBlank
	private String propietarioNombre;
	private String propietarioCedula;
	private String propietarioTelefono;
	private boolean estadoRegistro;
}
