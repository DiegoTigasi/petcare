package com.DiegoTigasi.petCareApi.infraestructura.repositorio;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.ConsultaEntity;

public interface IConsultaJpaRepositorio extends JpaRepository<ConsultaEntity, Integer> {

	@Query("SELECT DISTINCT c FROM ConsultaEntity c JOIN c.listaServicios s "
			+ "WHERE c.estado = 'ATENDIDA' AND c.fecha BETWEEN :desde AND :hasta")
	List<ConsultaEntity> listarAtencionesValidasEntreFechas(@Param("desde") Date desde, @Param("hasta") Date hasta);
}
