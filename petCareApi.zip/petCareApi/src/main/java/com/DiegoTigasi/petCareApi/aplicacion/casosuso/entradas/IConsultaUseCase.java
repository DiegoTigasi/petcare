package com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas;

import java.util.Date;
import java.util.List;

import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;

public interface IConsultaUseCase {

	Consulta guardar(Consulta nuevaConsulta);

	Consulta buscarPorId(int idConsulta);

	List<Consulta> listarTodos();

	void eliminar(int idConsulta);

	List<Consulta> listarAtencionesValidasEntreFechas(Date desde, Date hasta);
}
