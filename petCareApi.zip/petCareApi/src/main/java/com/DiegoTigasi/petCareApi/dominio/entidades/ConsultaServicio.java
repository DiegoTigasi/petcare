package com.DiegoTigasi.petCareApi.dominio.entidades;

public class ConsultaServicio {

	private int idConsultaServicio;
	private Consulta fkConsulta;
	private String servicioNombre;
	private double precio;
	private int cantidad;

	public int getIdConsultaServicio() {
		return idConsultaServicio;
	}
	public void setIdConsultaServicio(int idConsultaServicio) {
		this.idConsultaServicio = idConsultaServicio;
	}
	public Consulta getFkConsulta() {
		return fkConsulta;
	}
	public void setFkConsulta(Consulta fkConsulta) {
		this.fkConsulta = fkConsulta;
	}
	public String getServicioNombre() {
		return servicioNombre;
	}
	public void setServicioNombre(String servicioNombre) {
		this.servicioNombre = servicioNombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
}
