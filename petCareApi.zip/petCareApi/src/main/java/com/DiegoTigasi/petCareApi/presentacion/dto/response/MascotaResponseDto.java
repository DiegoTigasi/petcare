package com.DiegoTigasi.petCareApi.presentacion.dto.response;

import java.util.Date;

public class MascotaResponseDto {

	private int idMascota;
	private String nombre;
	private String especie;
	private String raza;
	private String sexo;
	private Date fechaNacimiento;
	private String propietarioNombre;
	private String propietarioCedula;
	private String propietarioTelefono;
	private boolean estadoRegistro;

	public int getIdMascota() {
		return idMascota;
	}
	public void setIdMascota(int idMascota) {
		this.idMascota = idMascota;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getRaza() {
		return raza;
	}
	public void setRaza(String raza) {
		this.raza = raza;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public String getPropietarioNombre() {
		return propietarioNombre;
	}
	public void setPropietarioNombre(String propietarioNombre) {
		this.propietarioNombre = propietarioNombre;
	}
	public String getPropietarioCedula() {
		return propietarioCedula;
	}
	public void setPropietarioCedula(String propietarioCedula) {
		this.propietarioCedula = propietarioCedula;
	}
	public String getPropietarioTelefono() {
		return propietarioTelefono;
	}
	public void setPropietarioTelefono(String propietarioTelefono) {
		this.propietarioTelefono = propietarioTelefono;
	}
	public boolean isEstadoRegistro() {
		return estadoRegistro;
	}
	public void setEstadoRegistro(boolean estadoRegistro) {
		this.estadoRegistro = estadoRegistro;
	}
}
