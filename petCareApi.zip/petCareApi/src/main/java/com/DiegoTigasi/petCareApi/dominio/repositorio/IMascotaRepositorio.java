package com.DiegoTigasi.petCareApi.dominio.repositorio;

import java.util.List;
import java.util.Optional;

import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;

public interface IMascotaRepositorio {

	Mascota guardar(Mascota nuevaMascota);

	Optional<Mascota> buscarPorId(int idMascota);

	List<Mascota> listarTodos();

	void eliminar(int idMascota);

	List<Mascota> buscarPorNombre(String nombre);
}
