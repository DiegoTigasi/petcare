package com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas;

import java.util.List;

import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;

public interface IMascotaUseCase {

	Mascota guardar(Mascota nuevaMascota);

	Mascota buscarPorId(int idMascota);

	List<Mascota> listarTodos();

	void eliminar(int idMascota);

	List<Mascota> buscarPorNombre(String nombre);
}
