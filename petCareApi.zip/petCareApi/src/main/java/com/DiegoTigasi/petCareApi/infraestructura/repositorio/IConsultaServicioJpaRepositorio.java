package com.DiegoTigasi.petCareApi.infraestructura.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.ConsultaServicioEntity;

public interface IConsultaServicioJpaRepositorio extends JpaRepository<ConsultaServicioEntity, Integer> {

	@Query("SELECT cs FROM ConsultaServicioEntity cs WHERE cs.fkConsultaEntity.idConsulta = :idConsulta")
	List<ConsultaServicioEntity> listarPorConsulta(@Param("idConsulta") int idConsulta);
}
