package com.DiegoTigasi.petCareApi.infraestructura.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.MascotaEntity;

public interface IMascotaJpaRepositorio extends JpaRepository<MascotaEntity, Integer> {

	List<MascotaEntity> findByNombreContainingIgnoreCase(String nombre);
}
