package com.DiegoTigasi.petCareApi.presentacion.dto.response;

import java.util.Date;

public class ConsultaReporteResponseDto {

	private String propietarioNombre;
	private String mascotaNombre;
	private String especie;
	private String veterinarioNombre;
	private Date fecha;

	public String getPropietarioNombre() {
		return propietarioNombre;
	}
	public void setPropietarioNombre(String propietarioNombre) {
		this.propietarioNombre = propietarioNombre;
	}
	public String getMascotaNombre() {
		return mascotaNombre;
	}
	public void setMascotaNombre(String mascotaNombre) {
		this.mascotaNombre = mascotaNombre;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getVeterinarioNombre() {
		return veterinarioNombre;
	}
	public void setVeterinarioNombre(String veterinarioNombre) {
		this.veterinarioNombre = veterinarioNombre;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
}
