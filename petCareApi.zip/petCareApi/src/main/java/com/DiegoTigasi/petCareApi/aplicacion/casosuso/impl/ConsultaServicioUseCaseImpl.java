package com.DiegoTigasi.petCareApi.aplicacion.casosuso.impl;

import java.util.List;

import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IConsultaServicioUseCase;
import com.DiegoTigasi.petCareApi.dominio.entidades.ConsultaServicio;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IConsultaServicioRepositorio;

public class ConsultaServicioUseCaseImpl implements IConsultaServicioUseCase {

	private final IConsultaServicioRepositorio repositorio;

	public ConsultaServicioUseCaseImpl(IConsultaServicioRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public ConsultaServicio guardar(ConsultaServicio nuevoConsultaServicio) {
		return repositorio.guardar(nuevoConsultaServicio);
	}

	@Override
	public ConsultaServicio buscarPorId(int idConsultaServicio) {
		return repositorio.buscarPorId(idConsultaServicio)
				.orElseThrow(() -> new RuntimeException("Servicio de consulta no encontrado"));
	}

	@Override
	public List<ConsultaServicio> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int idConsultaServicio) {
		repositorio.eliminar(idConsultaServicio);
	}

	@Override
	public List<ConsultaServicio> listarPorConsulta(int idConsulta) {
		return repositorio.listarPorConsulta(idConsulta);
	}
}
