package com.DiegoTigasi.petCareApi.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IMascotaRepositorio;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.MascotaEntity;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores.IMascotaJpaMapper;
import com.DiegoTigasi.petCareApi.infraestructura.repositorio.IMascotaJpaRepositorio;

public class MascotaRepositorioImpl implements IMascotaRepositorio {

	private final IMascotaJpaRepositorio jpaRepositorio;
	private final IMascotaJpaMapper entityMapper;

	public MascotaRepositorioImpl(IMascotaJpaRepositorio jpaRepositorio, IMascotaJpaMapper entityMapper) {
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Mascota guardar(Mascota nuevaMascota) {
		MascotaEntity entity = entityMapper.toEntity(nuevaMascota);
		MascotaEntity guardado = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardado);
	}

	@Override
	public Optional<Mascota> buscarPorId(int idMascota) {
		return jpaRepositorio.findById(idMascota).map(entityMapper::toDomain);
	}

	@Override
	public List<Mascota> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int idMascota) {
		jpaRepositorio.deleteById(idMascota);
	}

	@Override
	public List<Mascota> buscarPorNombre(String nombre) {
		return jpaRepositorio.findByNombreContainingIgnoreCase(nombre).stream().map(entityMapper::toDomain).toList();
	}
}
