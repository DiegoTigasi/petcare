package com.DiegoTigasi.petCareApi.presentacion.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ConsultaServicioRequestDto {

	private int idConsultaServicio;
	@Min(1)
	private int idConsulta;
	@NotBlank
	private String servicioNombre;
	@DecimalMin("0.0")
	private double precio;
	@Min(1)
	private int cantidad;
}
