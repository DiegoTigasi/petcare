package com.DiegoTigasi.petCareApi.presentacion.mapeadores;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.DiegoTigasi.petCareApi.dominio.entidades.ConsultaServicio;
import com.DiegoTigasi.petCareApi.presentacion.dto.request.ConsultaServicioRequestDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.ConsultaServicioResponseDto;

@Mapper(componentModel = "spring")
public interface IConsultaServicioDtoMapper {

	@Mapping(target = "fkConsulta", ignore = true)
	ConsultaServicio toDomain(ConsultaServicioRequestDto dto);

	ConsultaServicioResponseDto toResponseDto(ConsultaServicio consultaServicioPojo);
}
