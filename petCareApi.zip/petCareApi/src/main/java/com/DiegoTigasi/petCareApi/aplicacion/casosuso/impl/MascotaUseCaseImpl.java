package com.DiegoTigasi.petCareApi.aplicacion.casosuso.impl;

import java.util.List;

import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IMascotaUseCase;
import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;
import com.DiegoTigasi.petCareApi.dominio.repositorio.IMascotaRepositorio;

public class MascotaUseCaseImpl implements IMascotaUseCase {

	private final IMascotaRepositorio repositorio;

	public MascotaUseCaseImpl(IMascotaRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Mascota guardar(Mascota nuevaMascota) {
		return repositorio.guardar(nuevaMascota);
	}

	@Override
	public Mascota buscarPorId(int idMascota) {
		return repositorio.buscarPorId(idMascota)
				.orElseThrow(() -> new RuntimeException("Mascota no encontrada"));
	}

	@Override
	public List<Mascota> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int idMascota) {
		repositorio.eliminar(idMascota);
	}

	@Override
	public List<Mascota> buscarPorNombre(String nombre) {
		return repositorio.buscarPorNombre(nombre);
	}
}
