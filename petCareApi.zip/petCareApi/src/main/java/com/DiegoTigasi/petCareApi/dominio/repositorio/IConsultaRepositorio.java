package com.DiegoTigasi.petCareApi.dominio.repositorio;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;

public interface IConsultaRepositorio {

	Consulta guardar(Consulta nuevaConsulta);

	Optional<Consulta> buscarPorId(int idConsulta);

	List<Consulta> listarTodos();

	void eliminar(int idConsulta);

	List<Consulta> listarAtencionesValidasEntreFechas(Date desde, Date hasta);
}
