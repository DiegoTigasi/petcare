package com.DiegoTigasi.petCareApi.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IMascotaUseCase;
import com.DiegoTigasi.petCareApi.presentacion.dto.request.MascotaRequestDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.MascotaResponseDto;
import com.DiegoTigasi.petCareApi.presentacion.mapeadores.IMascotaDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/petcare/mascota")
public class MascotaController {

	private final IMascotaUseCase mascotaUseCase;
	private final IMascotaDtoMapper mapper;

	public MascotaController(IMascotaUseCase mascotaUseCase, IMascotaDtoMapper mapper) {
		this.mascotaUseCase = mascotaUseCase;
		this.mapper = mapper;
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public MascotaResponseDto guardar(@Valid @RequestBody MascotaRequestDto requestMascota) {
		return mapper.toResponseDto(mascotaUseCase.guardar(mapper.toDomain(requestMascota)));
	}

	@GetMapping
	public List<MascotaResponseDto> listarTodos() {
		return mascotaUseCase.listarTodos().stream().map(mapper::toResponseDto).toList();
	}

	@GetMapping("/{idMascota}")
	public MascotaResponseDto buscarPorId(@PathVariable int idMascota) {
		return mapper.toResponseDto(mascotaUseCase.buscarPorId(idMascota));
	}

	@PutMapping("/{idMascota}")
	public MascotaResponseDto editar(@PathVariable int idMascota, @Valid @RequestBody MascotaRequestDto requestMascota) {
		requestMascota.setIdMascota(idMascota);
		return mapper.toResponseDto(mascotaUseCase.guardar(mapper.toDomain(requestMascota)));
	}

	@DeleteMapping("/{idMascota}")
	public ResponseEntity<Void> eliminar(@PathVariable int idMascota) {
		mascotaUseCase.eliminar(idMascota);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/buscar/{nombre}")
	public List<MascotaResponseDto> buscarPorNombre(@PathVariable String nombre) {
		return mascotaUseCase.buscarPorNombre(nombre).stream().map(mapper::toResponseDto).toList();
	}
}
