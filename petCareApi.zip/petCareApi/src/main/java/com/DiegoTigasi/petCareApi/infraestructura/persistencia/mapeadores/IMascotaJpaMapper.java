package com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.MascotaEntity;

@Mapper(componentModel = "spring")
public interface IMascotaJpaMapper {

	Mascota toDomain(MascotaEntity entity);

	MascotaEntity toEntity(Mascota mascotaPojo);
}
