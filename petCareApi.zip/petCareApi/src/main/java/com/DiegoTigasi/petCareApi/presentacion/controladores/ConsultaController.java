package com.DiegoTigasi.petCareApi.presentacion.controladores;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.DiegoTigasi.petCareApi.aplicacion.casosuso.entradas.IConsultaUseCase;
import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;
import com.DiegoTigasi.petCareApi.dominio.entidades.Mascota;
import com.DiegoTigasi.petCareApi.presentacion.dto.request.ConsultaRequestDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.ConsultaReporteResponseDto;
import com.DiegoTigasi.petCareApi.presentacion.dto.response.ConsultaResponseDto;
import com.DiegoTigasi.petCareApi.presentacion.mapeadores.IConsultaDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/petcare/consulta")
public class ConsultaController {

	private final IConsultaUseCase consultaUseCase;
	private final IConsultaDtoMapper mapper;

	public ConsultaController(IConsultaUseCase consultaUseCase, IConsultaDtoMapper mapper) {
		this.consultaUseCase = consultaUseCase;
		this.mapper = mapper;
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public ConsultaResponseDto guardar(@Valid @RequestBody ConsultaRequestDto requestConsulta) {
		return mapper.toResponseDto(consultaUseCase.guardar(aDominioConFkMascota(requestConsulta)));
	}

	@GetMapping
	public List<ConsultaResponseDto> listarTodos() {
		return consultaUseCase.listarTodos().stream().map(mapper::toResponseDto).toList();
	}

	@GetMapping("/{idConsulta}")
	public ConsultaResponseDto buscarPorId(@PathVariable int idConsulta) {
		return mapper.toResponseDto(consultaUseCase.buscarPorId(idConsulta));
	}

	@PutMapping("/{idConsulta}")
	public ConsultaResponseDto editar(@PathVariable int idConsulta, @Valid @RequestBody ConsultaRequestDto requestConsulta) {
		requestConsulta.setIdConsulta(idConsulta);
		return mapper.toResponseDto(consultaUseCase.guardar(aDominioConFkMascota(requestConsulta)));
	}

	@DeleteMapping("/{idConsulta}")
	public ResponseEntity<Void> eliminar(@PathVariable int idConsulta) {
		consultaUseCase.eliminar(idConsulta);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/reporte")
	public List<ConsultaReporteResponseDto> reporteAtencionesValidas(
			@RequestParam @DateTimeFormat(iso = ISO.DATE) Date desde,
			@RequestParam @DateTimeFormat(iso = ISO.DATE) Date hasta) {
		return consultaUseCase.listarAtencionesValidasEntreFechas(desde, hasta).stream()
				.map(mapper::toReporteDto).toList();
	}

	private Consulta aDominioConFkMascota(ConsultaRequestDto requestConsulta) {
		Consulta consulta = mapper.toDomain(requestConsulta);
		Mascota mascotaRef = new Mascota();
		mascotaRef.setIdMascota(requestConsulta.getIdMascota());
		consulta.setFkMascota(mascotaRef);
		return consulta;
	}
}
