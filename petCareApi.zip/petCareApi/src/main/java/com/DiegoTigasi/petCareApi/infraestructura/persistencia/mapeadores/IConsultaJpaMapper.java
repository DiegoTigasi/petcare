package com.DiegoTigasi.petCareApi.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.DiegoTigasi.petCareApi.dominio.entidades.Consulta;
import com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa.ConsultaEntity;

@Mapper(componentModel = "spring", uses = IMascotaJpaMapper.class)
public interface IConsultaJpaMapper {

	@Mapping(source = "fkMascotaEntity", target = "fkMascota")
	Consulta toDomain(ConsultaEntity entity);

	ConsultaEntity toEntity(Consulta consultaPojo);
}
