package com.DiegoTigasi.petCareApi.dominio.entidades;

import java.util.Date;

public class Consulta {

	private int idConsulta;
	private Mascota fkMascota;
	private String veterinarioNombre;
	private Date fecha;
	private String motivo;
	private String diagnostico;
	private String estado;

	public int getIdConsulta() {
		return idConsulta;
	}
	public void setIdConsulta(int idConsulta) {
		this.idConsulta = idConsulta;
	}
	public Mascota getFkMascota() {
		return fkMascota;
	}
	public void setFkMascota(Mascota fkMascota) {
		this.fkMascota = fkMascota;
	}
	public String getVeterinarioNombre() {
		return veterinarioNombre;
	}
	public void setVeterinarioNombre(String veterinarioNombre) {
		this.veterinarioNombre = veterinarioNombre;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	public String getDiagnostico() {
		return diagnostico;
	}
	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
}
