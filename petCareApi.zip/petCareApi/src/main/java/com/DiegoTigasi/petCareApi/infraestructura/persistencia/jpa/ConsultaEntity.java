package com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "consulta")
public class ConsultaEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idConsulta;
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_mascota")
	private MascotaEntity fkMascotaEntity;
	private String veterinarioNombre;
	private Date fecha;
	private String motivo;
	private String diagnostico;
	private String estado;

	@OneToMany(mappedBy = "fkConsultaEntity")
	private List<ConsultaServicioEntity> listaServicios = new ArrayList<>();
}
