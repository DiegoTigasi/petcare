package com.DiegoTigasi.petCareApi.infraestructura.persistencia.jpa;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "mascota")
public class MascotaEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idMascota;
	private String nombre;
	private String especie;
	private String raza;
	private String sexo;
	private Date fechaNacimiento;
	private String propietarioNombre;
	private String propietarioCedula;
	private String propietarioTelefono;
	private boolean estadoRegistro;

	@OneToMany(mappedBy = "fkMascotaEntity")
	private List<ConsultaEntity> listaConsultas = new ArrayList<>();
}
